from __future__ import annotations

from pathlib import Path
from typing import Dict, List
from uuid import uuid4
from datetime import datetime
import os
import re
import sys

from fastapi import FastAPI, UploadFile, File, BackgroundTasks, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = Path(__file__).resolve().parent
ASSISTANT_DIR = BACKEND_DIR / "assistant_giga"
DATA_DIR = ASSISTANT_DIR / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)

# ВАЖНО: подгружаем .env ДО импорта и создания RAGPipeline.
load_dotenv(BACKEND_DIR / ".env")
load_dotenv(ROOT_DIR / ".env")

sys.path.insert(0, str(ASSISTANT_DIR))
from rag_pipeline import RAGPipeline  # noqa: E402

pipeline = RAGPipeline(
    collection_name="gigachat_rag_collection",
    cache_db_path=str(BACKEND_DIR / "gigachat_rag_cache.db"),
    data_file=str(DATA_DIR),
    model="GigaChat",
)

app = FastAPI(title="Avtoritet Assistant API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

TASKS: Dict[str, Dict[str, object]] = {}


def _sanitize_filename(filename: str) -> str:
    cleaned = re.sub(r"[^a-zA-Zа-яА-Я0-9._-]", "_", filename).strip("._")
    return cleaned or f"upload_{uuid4().hex}.bin"


def _require_admin_token(x_admin_token: str | None) -> None:
    expected = os.getenv("ADMIN_UPLOAD_TOKEN", "").strip()
    if not expected:
        return
    if x_admin_token != expected:
        raise HTTPException(status_code=401, detail="Неверный ADMIN token")


def _process_ingest_task(task_id: str, file_paths: List[str], replace: bool) -> None:
    TASKS[task_id]["status"] = "processing"
    TASKS[task_id]["started_at"] = datetime.utcnow().isoformat()

    try:
        result = pipeline.ingest_documents(file_paths=file_paths, replace=replace, clear_cache=True)
        TASKS[task_id]["status"] = "done"
        TASKS[task_id]["result"] = result
    except Exception as exc:
        TASKS[task_id]["status"] = "failed"
        TASKS[task_id]["error"] = str(exc)
    finally:
        TASKS[task_id]["finished_at"] = datetime.utcnow().isoformat()


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/api/chat/ask")
def chat_ask(payload: Dict[str, object]) -> Dict[str, object]:
    query = str(payload.get("query", "")).strip()
    if not query:
        raise HTTPException(status_code=400, detail="Поле query обязательно")

    use_cache = bool(payload.get("use_cache", True))
    result = pipeline.query(query, use_cache=use_cache)

    return {
        "answer": result.get("answer", ""),
        "from_cache": result.get("from_cache", False),
        "meta": {
            "model": result.get("model"),
            "retrieval": result.get("retrieval"),
            "top_k": result.get("top_k"),
        },
    }


@app.post("/api/admin/documents/upload")
async def upload_documents(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    replace: bool = True,
    x_admin_token: str | None = Header(default=None),
) -> Dict[str, object]:
    _require_admin_token(x_admin_token)

    if not files:
        raise HTTPException(status_code=400, detail="Файлы не переданы")

    saved_paths: List[str] = []
    saved_files: List[str] = []

    max_files = int(os.getenv("MAX_UPLOAD_FILES", "20"))
    if len(files) > max_files:
        raise HTTPException(status_code=400, detail=f"Слишком много файлов в одном запросе. Лимит: {max_files}")

    for upload in files:
        if not upload.filename:
            continue

        safe_name = _sanitize_filename(upload.filename)
        save_path = DATA_DIR / safe_name
        content = await upload.read()
        save_path.write_bytes(content)

        saved_paths.append(str(save_path.resolve()))
        saved_files.append(safe_name)

    if not saved_paths:
        raise HTTPException(status_code=400, detail="Не удалось сохранить файлы")

    task_id = uuid4().hex
    TASKS[task_id] = {
        "status": "queued",
        "created_at": datetime.utcnow().isoformat(),
        "files": saved_files,
        "replace": replace,
    }

    background_tasks.add_task(_process_ingest_task, task_id, saved_paths, replace)

    return {
        "task_id": task_id,
        "status": "queued",
        "files_saved": saved_files,
        "message": "Файлы сохранены. Индексация запущена автоматически.",
    }


@app.get("/api/admin/documents/tasks/{task_id}")
def get_task_status(task_id: str, x_admin_token: str | None = Header(default=None)) -> Dict[str, object]:
    _require_admin_token(x_admin_token)

    task = TASKS.get(task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Задача не найдена")

    return {"task_id": task_id, **task}
