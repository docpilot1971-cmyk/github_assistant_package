"""
Модуль работы с векторным хранилищем ChromaDB для GigaChat.
Поддерживает загрузку разных форматов документов и гибридный поиск.
"""

from __future__ import annotations

from typing import List, Dict, Any, Iterable
from pathlib import Path
from datetime import datetime
import os
import re
import uuid

import chromadb
from rank_bm25 import BM25Okapi

try:
    from .gigachat_client import GigaChatClient
    from .document_processor import DocumentProcessor, SUPPORTED_EXTENSIONS
except ImportError:
    from gigachat_client import GigaChatClient
    from document_processor import DocumentProcessor, SUPPORTED_EXTENSIONS


class VectorStore:
    """Векторное хранилище на основе ChromaDB с GigaChat embeddings."""

    def __init__(self, collection_name: str = "rag_collection", persist_directory: str = "./chroma_db"):
        self.collection_name = collection_name
        self.persist_directory = persist_directory

        self.client = chromadb.PersistentClient(path=persist_directory)

        try:
            self.collection = self.client.get_collection(name=collection_name)
            print(f"Коллекция '{collection_name}' загружена. Документов: {self.collection.count()}")
        except Exception:
            self.collection = self.client.create_collection(
                name=collection_name,
                metadata={"hnsw:space": "cosine"}
            )
            print(f"Создана новая коллекция '{collection_name}'")

        self.gigachat_client = GigaChatClient()
        self.processor = DocumentProcessor(
            max_file_size_mb=int(os.getenv("MAX_UPLOAD_SIZE_MB", "25")),
            enable_ocr=os.getenv("ENABLE_OCR", "true").lower() == "true",
        )

    def load_documents(self, file_paths: Iterable[str], replace: bool = True) -> Dict[str, Any]:
        """
        Загрузка документов в векторное хранилище.

        Args:
            file_paths: список путей к файлам
            replace: удалять старые чанки документа перед загрузкой новых

        Returns:
            статистика загрузки
        """
        processed = 0
        failed = 0
        total_chunks = 0
        errors: List[Dict[str, str]] = []

        for raw_path in file_paths:
            path = Path(raw_path)

            try:
                doc = self.processor.process_file(str(path))

                if replace:
                    self.collection.delete(where={"source_path": doc.source_path})

                docs: List[str] = []
                ids: List[str] = []
                embeddings: List[List[float]] = []
                metadatas: List[Dict[str, Any]] = []

                batch_size = 32
                for chunk_idx, chunk in enumerate(doc.chunks):
                    docs.append(chunk)
                    ids.append(f"{doc.file_hash[:12]}_{chunk_idx}_{uuid.uuid4().hex[:8]}")
                    metadatas.append({
                        "source": doc.source_name,
                        "source_path": doc.source_path,
                        "source_ext": doc.extension,
                        "file_hash": doc.file_hash,
                        "chunk_index": chunk_idx,
                        "updated_at": datetime.utcnow().isoformat(),
                    })

                    if len(docs) == batch_size:
                        embeddings.extend(self._create_embeddings(docs[-batch_size:]))

                remainder = len(docs) % batch_size
                if remainder:
                    embeddings.extend(self._create_embeddings(docs[-remainder:]))

                if docs:
                    self.collection.add(
                        documents=docs,
                        embeddings=embeddings,
                        metadatas=metadatas,
                        ids=ids,
                    )

                processed += 1
                total_chunks += len(doc.chunks)
                print(f"✓ Загружен {doc.source_name}: {len(doc.chunks)} чанков")

            except Exception as exc:
                failed += 1
                errors.append({"file": str(path), "error": str(exc)})
                print(f"✗ Ошибка обработки {path.name}: {exc}")

        return {
            "processed_files": processed,
            "failed_files": failed,
            "total_chunks": total_chunks,
            "errors": errors,
            "collection_count": self.collection.count(),
        }

    def search(self, query: str, top_k: int = 3, alpha: float = 0.7) -> List[Dict[str, Any]]:
        """
        Гибридный поиск: векторный + BM25 keyword.

        Args:
            query: текст запроса
            top_k: количество документов для возврата
            alpha: вес векторного скоринга (0..1)

        Returns:
            список документов с оценками
        """
        if self.collection.count() == 0:
            return []

        vector_candidates = self._vector_search(query, max(top_k * 4, 10))
        keyword_candidates = self._keyword_search(query, max(top_k * 4, 10))

        merged: Dict[str, Dict[str, Any]] = {}

        for item in vector_candidates:
            key = item["id"]
            merged[key] = {
                **item,
                "vector_score": item["score"],
                "keyword_score": 0.0,
                "score": item["score"] * alpha,
            }

        for item in keyword_candidates:
            key = item["id"]
            if key not in merged:
                merged[key] = {
                    **item,
                    "vector_score": 0.0,
                    "keyword_score": item["score"],
                    "score": item["score"] * (1 - alpha),
                }
            else:
                merged[key]["keyword_score"] = item["score"]
                merged[key]["score"] += item["score"] * (1 - alpha)

        ranked = sorted(merged.values(), key=lambda x: x["score"], reverse=True)
        return ranked[:top_k]

    def _vector_search(self, query: str, top_n: int) -> List[Dict[str, Any]]:
        query_embedding = self._create_embedding(query)
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=min(top_n, self.collection.count()),
            include=["documents", "distances", "metadatas"],
        )

        docs: List[Dict[str, Any]] = []
        if results.get("documents") and results["documents"][0]:
            for i in range(len(results["documents"][0])):
                distance = results["distances"][0][i] if results.get("distances") else 1.0
                score = 1.0 / (1.0 + max(distance, 0.0))
                docs.append({
                    "id": results["ids"][0][i],
                    "text": results["documents"][0][i],
                    "distance": distance,
                    "score": score,
                    "metadata": results["metadatas"][0][i] if results.get("metadatas") else None,
                })
        return docs

    def _keyword_search(self, query: str, top_n: int) -> List[Dict[str, Any]]:
        corpus = self.collection.get(include=["documents", "metadatas"])
        documents = corpus.get("documents", [])
        ids = corpus.get("ids", [])
        metadatas = corpus.get("metadatas", [])

        if not documents:
            return []

        tokenized_corpus = [self._tokenize(doc) for doc in documents]
        tokenized_query = self._tokenize(query)

        if not tokenized_query:
            return []

        bm25 = BM25Okapi(tokenized_corpus)
        scores = bm25.get_scores(tokenized_query)

        max_score = max(scores) if len(scores) else 0.0
        if max_score <= 0:
            return []

        ranked_idx = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_n]

        result: List[Dict[str, Any]] = []
        for i in ranked_idx:
            normalized_score = float(scores[i] / max_score) if max_score else 0.0
            result.append({
                "id": ids[i],
                "text": documents[i],
                "distance": None,
                "score": normalized_score,
                "metadata": metadatas[i] if i < len(metadatas) else None,
            })
        return result

    def _create_embedding(self, text: str) -> List[float]:
        embeddings = self.gigachat_client.get_embeddings([text])
        return embeddings[0]

    def _create_embeddings(self, texts: List[str]) -> List[List[float]]:
        return self.gigachat_client.get_embeddings(texts)

    @staticmethod
    def _tokenize(text: str) -> List[str]:
        # RU+EN токенизация для брендов и технических терминов.
        return re.findall(r"[a-zA-Zа-яА-Я0-9_\-]+", text.lower())

    def list_supported_extensions(self) -> List[str]:
        return sorted(SUPPORTED_EXTENSIONS)

    def get_collection_stats(self) -> Dict[str, Any]:
        return {
            "name": self.collection_name,
            "count": self.collection.count(),
            "persist_directory": self.persist_directory,
            "supported_extensions": self.list_supported_extensions(),
        }
