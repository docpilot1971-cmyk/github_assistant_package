"""
Основной RAG pipeline для GigaChat.
Управляет потоком: запрос -> кеш -> hybrid search -> GigaChat -> ответ -> кеш.
"""

from __future__ import annotations

from typing import Dict, Any, List
import os
from pathlib import Path

try:
    from .gigachat_client import GigaChatClient
    from .vector_store import VectorStore
    from .cache import RAGCache
except ImportError:
    from gigachat_client import GigaChatClient
    from vector_store import VectorStore
    from cache import RAGCache


class RAGPipeline:
    """Основной pipeline для RAG системы с GigaChat."""

    def __init__(self,
                 collection_name: str = "rag_collection",
                 cache_db_path: str = "rag_cache.db",
                 data_file: str = "data",
                 model: str = "GigaChat"):
        if not os.getenv("GIGACHAT_AUTH_KEY"):
            raise ValueError("GIGACHAT_AUTH_KEY не установлен")
        if not os.getenv("GIGACHAT_RQUID"):
            raise ValueError("GIGACHAT_RQUID не установлен")

        self.model = model
        self.gigachat_client = GigaChatClient()

        print("Инициализация векторного хранилища...")
        self.vector_store = VectorStore(collection_name=collection_name)

        # Первичная индексация только для пустой коллекции.
        if self.vector_store.collection.count() == 0:
            initial_files = self._resolve_initial_files(data_file)
            if initial_files:
                print(f"Первичная загрузка {len(initial_files)} файлов...")
                self.vector_store.load_documents(initial_files, replace=True)
            else:
                print(f"Внимание: не найдено файлов для первичной загрузки в {data_file}")

        print("Инициализация кеша...")
        self.cache = RAGCache(db_path=cache_db_path)

        print("RAG Pipeline инициализирован (GigaChat)")

    def ingest_documents(self, file_paths: List[str], replace: bool = True, clear_cache: bool = True) -> Dict[str, Any]:
        """
        Метод для админ-панели: загрузка и индексация документов.

        Args:
            file_paths: список путей к загруженным файлам на сервере
            replace: заменять существующие чанки по source_path
            clear_cache: очищать кеш после обновления индекса
        """
        stats = self.vector_store.load_documents(file_paths=file_paths, replace=replace)

        if clear_cache and stats.get("processed_files", 0) > 0:
            self.cache.clear()
            stats["cache_cleared"] = True
        else:
            stats["cache_cleared"] = False

        return stats

    def _resolve_initial_files(self, data_path: str) -> List[str]:
        path = Path(data_path)

        if path.is_file():
            return [str(path.resolve())]

        if path.is_dir():
            files: List[str] = []
            for ext in self.vector_store.list_supported_extensions():
                files.extend([str(p.resolve()) for p in path.rglob(f"*{ext}")])
            return sorted(set(files))

        return []

    def _create_prompt(self, query: str, context_docs: List[Dict[str, Any]]) -> str:
        context_parts = []
        for i, doc in enumerate(context_docs, 1):
            context_parts.append(f"Документ {i}:\n{doc['text']}\n")

        context = "\n".join(context_parts)

        prompt = f"""Ты - полезный AI ассистент. Ответь на вопрос пользователя на основе предоставленного контекста.

Контекст:
{context}

Вопрос: {query}

Инструкции:
- Отвечай только на основе предоставленного контекста
- Если в контексте нет информации для ответа, скажи об этом
- Будь точным и кратким
- Отвечай на русском языке

Ответ:"""

        return prompt

    def _generate_answer(self, prompt: str) -> str:
        messages = [
            {"role": "system", "content": "Ты - полезный AI ассистент, который отвечает на вопросы на основе предоставленного контекста."},
            {"role": "user", "content": prompt}
        ]

        answer = self.gigachat_client.chat_completion(
            messages=messages,
            model=self.model,
            temperature=0.3,
            max_tokens=500
        )

        return answer.strip()

    def query(self, user_query: str, use_cache: bool = True) -> Dict[str, Any]:
        print(f"\n{'='*60}")
        print(f"Запрос: {user_query}")
        print(f"{'='*60}")

        if use_cache:
            print("-> Проверка кеша...")
            cached_result = self.cache.get(user_query)

            if cached_result:
                print("✓ Ответ найден в кеше")
                return {
                    "query": user_query,
                    "answer": cached_result["answer"],
                    "from_cache": True,
                    "context_docs": cached_result.get("context"),
                    "cached_at": cached_result.get("created_at")
                }
            print("✗ Ответ не найден в кеше")

        top_k = int(os.getenv("SEARCH_TOP_K", "4"))
        alpha = float(os.getenv("HYBRID_ALPHA", "0.7"))

        print("-> Гибридный поиск релевантных документов...")
        context_docs = self.vector_store.search(user_query, top_k=top_k, alpha=alpha)
        print(f"✓ Найдено {len(context_docs)} релевантных документов")

        print("-> Формирование промпта...")
        prompt = self._create_prompt(user_query, context_docs)

        print(f"-> Генерация ответа через {self.model}...")
        answer = self._generate_answer(prompt)
        print("✓ Ответ получен")

        if use_cache:
            print("-> Сохранение в кеш...")
            context_for_cache = [doc['text'] for doc in context_docs]
            saved = self.cache.set(user_query, answer, context_for_cache)
            if saved:
                print("✓ Сохранено в кеш")
            else:
                print("⚠ Пропущено: запрос/контекст вне тематики сайта")

        return {
            "query": user_query,
            "answer": answer,
            "from_cache": False,
            "context_docs": context_docs,
            "model": self.model,
            "retrieval": "hybrid",
            "top_k": top_k,
            "alpha": alpha,
        }

    def get_stats(self) -> Dict[str, Any]:
        return {
            "vector_store": self.vector_store.get_collection_stats(),
            "cache": self.cache.get_stats(),
            "model": self.model,
            "retrieval": "hybrid",
        }
