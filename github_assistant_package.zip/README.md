# Avtoritet Assistant Package

Пакет для публикации ассистента в GitHub.

## Состав
- `backend/app.py` — FastAPI backend (chat + admin upload/tasks)
- `backend/assistant_giga/*` — RAG pipeline, vector store, обработка документов
- `backend/requirements.txt` — зависимости backend
- `backend/.env.example` — пример переменных окружения
- `js/assistant-widget.js` — фронтовый виджет чата

## Быстрый запуск
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
# заполните GIGACHAT_AUTH_KEY и GIGACHAT_RQUID
uvicorn app:app --host 0.0.0.0 --port 8000
```

Проверка:
- `GET http://localhost:8000/health`
- `POST http://localhost:8000/api/chat/ask`
- `POST http://localhost:8000/api/admin/documents/upload`

## Интеграция в сайт
Подключить в HTML перед `</body>`:
```html
<script src="js/assistant-widget.js"></script>
```

По умолчанию виджет использует `http://localhost:8000/api`.
Для другого адреса задайте перед виджетом:
```html
<script>window.ASSISTANT_API_BASE = "https://your-domain/api";</script>
```
